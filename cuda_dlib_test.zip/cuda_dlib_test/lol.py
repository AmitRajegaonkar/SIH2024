import winsound

winsound.Beep(3000,5000)